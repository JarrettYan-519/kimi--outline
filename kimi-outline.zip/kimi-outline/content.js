/**
 * Kimi Chat Outline - content.js
 * Injects a floating outline sidebar into kimi.moonshot.cn / www.kimi.com
 */

(function () {
  'use strict';

  const LOG = '[KimiOutline]';
  const PREVIEW_LENGTH = 40;
  const DEBOUNCE_MS = 200;
  const RETRY_DELAY_MS = 1500;
  const MAX_RETRIES = 12;

  const USER_MSG_SELECTORS = [
    '.segment-user',
    '.chat-content-item-user',
    '[data-role="user"]',
    '[data-author="user"]',
    '[data-testid="user-message"]',
    '.chat-user-message',
    '.user-message',
    '[class*="userMessage"]',
    '[class*="user-message"]',
    '[class*="UserMessage"]',
    '[class*="user"][class*="bubble"]',
    '[class*="human"][class*="message"]',
  ];

  // ─── State ────────────────────────────────────────────────────────────────

  let panel = null;
  let toggleBtn = null;
  let listEl = null;
  let countEl = null;

  let collapsed = false;
  let activeSelector = null;
  let msgObserver = null;
  let intersectionObserver = null;
  let retryCount = 0;
  let debounceTimer = null;
  let highlightTimer = null;

  // Persistent outline state — accumulates all seen messages, never shrinks
  let messageStore = [];        // [{text: string, el: Element|null}]
  let lastRenderedTexts = [];   // snapshot of messageStore texts at last DOM rebuild
  let cachedScrollContainer = null;
  let activeIdx = -1;

  // ─── Utility ──────────────────────────────────────────────────────────────

  function debounce(fn, ms) {
    return function (...args) {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => fn.apply(this, args), ms);
    };
  }

  function textPreview(el) {
    const src = el.querySelector('.segment-content-box') || el;
    const raw = (src.innerText || src.textContent || '').trim().replace(/\s+/g, ' ');
    return raw.length <= PREVIEW_LENGTH ? raw : raw.slice(0, PREVIEW_LENGTH) + '…';
  }

  // ─── Selector / Debug ─────────────────────────────────────────────────────

  function detectSelector() {
    for (const sel of USER_MSG_SELECTORS) {
      try {
        if (document.querySelectorAll(sel).length > 0) {
          console.log(`${LOG} Matched selector: "${sel}"`);
          return sel;
        }
      } catch (e) { /* skip */ }
    }
    return null;
  }

  function debugDump() {
    console.group(`${LOG} DEBUG MODE — no selector matched`);
    const candidates = document.querySelectorAll(
      '[class*="chat"],[class*="message"],[class*="bubble"],[class*="segment"],[class*="turn"]'
    );
    const seen = new Set();
    for (const el of candidates) {
      const key = el.tagName + '.' + [...el.classList].join('.');
      if (!seen.has(key) && seen.size < 25) {
        seen.add(key);
        console.log(key, '→', (el.innerText || '').slice(0, 60));
      }
    }
    console.groupEnd();
  }

  // ─── DOM Helpers ──────────────────────────────────────────────────────────

  function getUserMessages() {
    if (!activeSelector) return [];
    try { return [...document.querySelectorAll(activeSelector)]; }
    catch (e) { return []; }
  }

  function findScrollContainer() {
    const msgs = getUserMessages();
    if (!msgs.length) return null;
    let el = msgs[0].parentElement;
    while (el && el !== document.body) {
      const ov = window.getComputedStyle(el).overflowY;
      if ((ov === 'auto' || ov === 'scroll' || ov === 'overlay') && el.scrollHeight > el.clientHeight) return el;
      el = el.parentElement;
    }
    return null;
  }

  function getScrollContainer() {
    if (cachedScrollContainer && cachedScrollContainer.isConnected)
      return cachedScrollContainer;
    cachedScrollContainer = findScrollContainer();
    return cachedScrollContainer;
  }

  /**
   * Merge newly visible DOM messages into the persistent messageStore.
   *
   * Key insight: when ALL existing store entries are virtualized (el=null),
   * compareDocumentPosition is useless. We process new messages in REVERSE
   * DOM order so the first insertion uses a scroll-position heuristic, and
   * every subsequent insertion can use the previously-inserted (now connected)
   * element as an anchor — keeping the store in correct conversation order.
   */
  function updateMessageStore(liveMsgs) {
    if (liveMsgs.length === 0) {
      messageStore.forEach(entry => {
        if (entry.el && !entry.el.isConnected) entry.el = null;
      });
      return;
    }

    // Sort liveMsgs by DOM order (all currently connected)
    const sorted = liveMsgs.length > 1
      ? [...liveMsgs].sort((a, b) =>
          (a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING) ? -1 : 1)
      : [...liveMsgs];

    // Update el for already-known messages; collect truly new ones.
    // Use positional (ordinal) matching for duplicate-text messages:
    // the Nth same-text DOM element maps to the Nth same-text store entry.
    const toInsert = sorted.filter(el => {
      const text = textPreview(el);
      const sameTextInStore = messageStore.filter(e => e.text === text);
      if (sameTextInStore.length === 0) return true; // genuinely new message
      const sameTextInDom = sorted.filter(d => textPreview(d) === text);
      const ordinal = sameTextInDom.indexOf(el);
      // Match by ordinal; fall back to last entry if DOM has more than store
      const target = sameTextInStore[ordinal] ?? sameTextInStore[sameTextInStore.length - 1];
      target.el = el;
      return false;
    });

    // Insert new messages in REVERSE DOM order.
    // After the first insertion, that element becomes a connected anchor,
    // so all subsequent insertions can use compareDocumentPosition correctly.
    for (let k = toInsert.length - 1; k >= 0; k--) {
      const newEl = toInsert[k];
      const text = textPreview(newEl);
      let insertAt = messageStore.length;
      let foundConnectedRef = false;

      for (let i = 0; i < messageStore.length; i++) {
        const ref = messageStore[i].el;
        if (ref && ref.isConnected) {
          foundConnectedRef = true;
          if (ref.compareDocumentPosition(newEl) & Node.DOCUMENT_POSITION_PRECEDING) {
            insertAt = i;
            break;
          }
        }
      }

      if (!foundConnectedRef) {
        // No connected anchors — infer position from scroll ratio.
        // Kimi renders at the bottom on load, so ratio≈0 means we're viewing
        // earlier messages that belong before the existing (bottom-loaded) entries.
        const cont = cachedScrollContainer || findScrollContainer();
        if (cont) {
          const ratio = cont.scrollTop / Math.max(cont.scrollHeight - cont.clientHeight, 1);
          if (ratio < 0.4) insertAt = 0;
          // else: ratio≥0.4 → new messages are from the lower portion → append
        }
      }

      messageStore.splice(insertAt, 0, { text, el: newEl });
    }

    // Mark disconnected elements (after all insertions)
    messageStore.forEach(entry => {
      if (entry.el && !entry.el.isConnected) entry.el = null;
    });

    // Recompute dupIdx for every entry so findLiveElement can use ordinal matching.
    // dupIdx = "among all store entries with the same text, I am the Nth one (0-based)".
    const textCounts = {};
    messageStore.forEach(entry => {
      entry.dupIdx = textCounts[entry.text] ?? 0;
      textCounts[entry.text] = (textCounts[entry.text] ?? 0) + 1;
    });
  }

  // ─── UI Construction ──────────────────────────────────────────────────────

  function buildUI() {
    if (document.getElementById('kimi-outline-panel')) return;

    panel = document.createElement('div');
    panel.id = 'kimi-outline-panel';
    if (collapsed) panel.classList.add('kimi-outline-collapsed');

    const header = document.createElement('div');
    header.className = 'kimi-outline-header';

    const headerLeft = document.createElement('div');
    headerLeft.className = 'kimi-outline-header-left';

    const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    icon.setAttribute('viewBox', '0 0 24 24');
    icon.setAttribute('fill', 'none');
    icon.setAttribute('stroke', 'currentColor');
    icon.setAttribute('stroke-width', '2');
    icon.setAttribute('stroke-linecap', 'round');
    icon.setAttribute('stroke-linejoin', 'round');
    icon.classList.add('kimi-outline-header-icon');
    icon.innerHTML = `
      <!-- Cute Robot Face (Looking Right) -->
      <circle cx="7" cy="12" r="5" fill="#4D7CFE" stroke="none"/>
      <ellipse cx="8" cy="11.5" rx="0.8" ry="1.2" fill="white" stroke="none"/>
      <ellipse cx="10.5" cy="11.5" rx="0.8" ry="1.2" fill="white" stroke="none"/>
      
      <!-- The Outline being read -->
      <path d="M15 8h6" stroke-width="2.5" />
      <path d="M15 12h4" stroke-width="2" opacity="0.7"/>
      <path d="M15 16h5" stroke-width="2" opacity="0.4"/>
      
      <!-- Reading Ray / Scan line -->
      <path d="M12 12l2-2" stroke="#4D7CFE" stroke-width="1" opacity="0.5" stroke-dasharray="2 1"/>
    `;

    const title = document.createElement('span');
    title.textContent = '内容大纲';

    headerLeft.appendChild(icon);
    headerLeft.appendChild(title);

    countEl = document.createElement('span');
    countEl.className = 'kimi-outline-count';

    header.appendChild(headerLeft);
    header.appendChild(countEl);

    listEl = document.createElement('div');
    listEl.className = 'kimi-outline-list';

    panel.appendChild(header);
    panel.appendChild(listEl);
    document.body.appendChild(panel);

    toggleBtn = document.createElement('button');
    toggleBtn.id = 'kimi-outline-toggle';
    toggleBtn.title = '折叠/展开大纲';
    updateToggleIcon();
    
    // Initial position logic
    if (!collapsed) {
      toggleBtn.style.right = '284px'; // 260 width + 12 gap + 12 offset
    } else {
      toggleBtn.style.right = '20px';
    }
    
    toggleBtn.addEventListener('click', togglePanel);
    document.body.appendChild(toggleBtn);
  }

  function updateToggleIcon() {
    if (!toggleBtn) return;
    const isCollapsed = collapsed;
    toggleBtn.innerHTML = `
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        ${isCollapsed 
          ? '<polyline points="15 18 9 12 15 6"></polyline>' 
          : '<polyline points="9 18 15 12 9 6"></polyline>'}
      </svg>
    `;
  }

  function togglePanel() {
    collapsed = !collapsed;
    panel.classList.toggle('kimi-outline-collapsed', collapsed);
    updateToggleIcon();
    
    if (!collapsed) {
      toggleBtn.style.right = '284px';
    } else {
      toggleBtn.style.right = '20px';
    }
  }

  // ─── Outline Rendering ────────────────────────────────────────────────────

  function rebuildOutline() {
    if (!listEl) return;

    const msgs = getUserMessages();

    // Accumulate all seen messages into the persistent store
    updateMessageStore(msgs);

    const storeTexts = messageStore.map(e => e.text);

    // ── Diff check: skip full DOM rebuild if store hasn't changed ────────
    if (
      storeTexts.length === lastRenderedTexts.length &&
      storeTexts.every((t, i) => t === lastRenderedTexts[i])
    ) {
      attachIntersectionObserver();
      return;
    }

    // ── Full rebuild ─────────────────────────────────────────────────────
    lastRenderedTexts = storeTexts.slice();
    listEl.innerHTML = '';

    if (messageStore.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'kimi-outline-empty';
      empty.textContent = '暂无消息\n对话开始后自动更新';
      listEl.appendChild(empty);
      countEl.textContent = '';
      activeIdx = -1;
      return;
    }

    countEl.textContent = `${messageStore.length} 条`;

    messageStore.forEach((entry, i) => {
      const item = document.createElement('div');
      item.className = 'kimi-outline-item';
      if (i === activeIdx) item.classList.add('kimi-outline-active');

      const num = document.createElement('span');
      num.className = 'kimi-outline-num';
      num.textContent = (i + 1).toString().padStart(2, '0'); // 使用 01, 02 这种更整齐的格式

      const text = document.createElement('span');
      text.className = 'kimi-outline-text';
      text.textContent = entry.text;

      item.appendChild(num);
      item.appendChild(text);
      item.addEventListener('click', () => handleItemClick(i, item));
      listEl.appendChild(item);
    });

    attachIntersectionObserver();
  }

  const rebuildDebounced = debounce(rebuildOutline, DEBOUNCE_MS);

  // ─── Click Navigation ────────────────────────────────────────────────────

  /**
   * Find the live DOM element for outline item at `idx`.
   * Uses the messageStore entry; refreshes the cached el if needed.
   */
  function findLiveElement(idx) {
    const entry = messageStore[idx];
    if (!entry) return null;
    if (entry.el && entry.el.isConnected) return entry.el;
    // Cached el is stale — re-match from current DOM using ordinal to avoid
    // selecting the wrong element when two messages share the same text preview.
    const msgs = getUserMessages();
    const targetOrdinal = entry.dupIdx ?? 0;
    let seen = 0;
    const fresh = msgs.find(el => {
      if (textPreview(el) !== entry.text) return false;
      if (seen === targetOrdinal) return true;
      seen++;
      return false;
    });
    if (fresh) entry.el = fresh;
    return fresh || null;
  }

  /**
   * When the target element is off-screen (virtual scroll), scroll the
   * container toward it.
   *
   * finetune=false (default): ratio-based jump — one-shot estimate to target position.
   * finetune=true: scrollBy based on where visible messages sit relative to target.
   */
  function scrollContainerToward(targetIdx, finetune = false) {
    const container = getScrollContainer();
    if (!container) return;

    const msgs = getUserMessages();
    // Use ordinal counting so duplicate-text messages map to the correct store entry
    const textSeenCount = {};
    const visibleStoreIndices = msgs.map(el => {
      const text = textPreview(el);
      const ordinal = textSeenCount[text] ?? 0;
      textSeenCount[text] = ordinal + 1;
      return messageStore.findIndex(e => e.text === text && (e.dupIdx ?? 0) === ordinal);
    }).filter(i => i !== -1);

    if (!finetune || visibleStoreIndices.length === 0) {
      // Main jump: ratio estimate, instant so it completes before our setTimeout fires
      const ratio = targetIdx / Math.max(messageStore.length - 1, 1);
      container.scrollTo({
        top: Math.round(ratio * (container.scrollHeight - container.clientHeight)),
        behavior: 'instant'
      });
      return;
    }

    // Fine-tune: one viewport nudge in the right direction
    const minVisible = Math.min(...visibleStoreIndices);
    const maxVisible = Math.max(...visibleStoreIndices);
    if (targetIdx < minVisible) {
      container.scrollBy({ top: -container.clientHeight * 0.85, behavior: 'smooth' });
    } else if (targetIdx > maxVisible) {
      container.scrollBy({ top: container.clientHeight * 0.85, behavior: 'smooth' });
    }
  }

  /**
   * Scroll the known container so that `el` appears at the top of the viewport.
   * Falls back to native scrollIntoView if no container is found.
   */
  function scrollToElement(el) {
    const container = getScrollContainer();
    if (!container) {
      el.scrollIntoView({ block: 'start' });
      return;
    }
    const elRect = el.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();
    // Direct scrollTop assignment — synchronous, bypasses Kimi's scroll event listeners
    container.scrollTop = container.scrollTop + (elRect.top - containerRect.top);
  }

  function handleItemClick(idx, itemEl) {
    const msgEl = findLiveElement(idx);
    if (msgEl) {
      scrollToElement(msgEl);
      flashItem(itemEl);
      return;
    }

    // Element is virtualized — instant ratio jump to estimated position
    scrollContainerToward(idx, false);

    setTimeout(() => {
      updateMessageStore(getUserMessages());
      const el1 = findLiveElement(idx);
      if (el1) { scrollToElement(el1); flashItem(itemEl); return; }
      // Fine-tune nudge #1
      scrollContainerToward(idx, true);
      setTimeout(() => {
        updateMessageStore(getUserMessages());
        const el2 = findLiveElement(idx);
        if (el2) { scrollToElement(el2); flashItem(itemEl); return; }
        // Fine-tune nudge #2
        scrollContainerToward(idx, true);
        setTimeout(() => {
          updateMessageStore(getUserMessages());
          const el3 = findLiveElement(idx);
          if (el3) { scrollToElement(el3); flashItem(itemEl); }
        }, 600);
      }, 600);
    }, 500);
  }

  function flashItem(itemEl) {
    itemEl.classList.remove('kimi-outline-flash-item');
    void itemEl.offsetWidth;
    itemEl.classList.add('kimi-outline-flash-item');
    setTimeout(() => itemEl.classList.remove('kimi-outline-flash-item'), 1500);
  }

  // ─── Active Highlight ─────────────────────────────────────────────────────

  function setActiveItem(index) {
    if (activeIdx === index) return;
    activeIdx = index;
    const items = listEl?.querySelectorAll('.kimi-outline-item');
    if (!items) return;
    items.forEach((it, i) => it.classList.toggle('kimi-outline-active', i === index));
    items[index]?.scrollIntoView({ block: 'nearest' });
  }

  // ─── IntersectionObserver ─────────────────────────────────────────────────

  function attachIntersectionObserver() {
    if (intersectionObserver) { intersectionObserver.disconnect(); intersectionObserver = null; }

    const msgs = getUserMessages();
    if (msgs.length === 0) return;

    const visibilityMap = new Map();

    intersectionObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const idx = msgs.indexOf(entry.target);
        if (idx !== -1) visibilityMap.set(idx, entry.isIntersecting);
      });

      // Debounce: let scroll settle before updating highlight
      clearTimeout(highlightTimer);
      highlightTimer = setTimeout(() => {
        // Map DOM index → store index via ordinal-aware text matching
        const seenCount = {};
        let topOutlineIdx = -1;
        for (let i = 0; i < msgs.length; i++) {
          const text = textPreview(msgs[i]);
          const ordinal = seenCount[text] ?? 0;
          seenCount[text] = ordinal + 1;
          if (visibilityMap.get(i)) {
            const oi = messageStore.findIndex(e => e.text === text && (e.dupIdx ?? 0) === ordinal);
            if (oi !== -1) { topOutlineIdx = oi; break; }
          }
        }
        if (topOutlineIdx !== -1) setActiveItem(topOutlineIdx);
      }, 100);

    }, { root: getScrollContainer(), threshold: 0.2 });

    msgs.forEach(el => intersectionObserver.observe(el));
  }

  // ─── MutationObserver ─────────────────────────────────────────────────────

  function startMsgObserver() {
    if (msgObserver) msgObserver.disconnect();

    msgObserver = new MutationObserver((mutations) => {
      const relevant = mutations.some(m =>
        !(panel && panel.contains(m.target)) &&
        !(toggleBtn && toggleBtn.contains(m.target))
      );
      if (relevant) rebuildDebounced();
    });

    msgObserver.observe(document.body, { childList: true, subtree: true });
  }

  // ─── Bootstrap ────────────────────────────────────────────────────────────

  function tryInit() {
    activeSelector = detectSelector();

    if (!activeSelector) {
      retryCount++;
      if (retryCount <= MAX_RETRIES) {
        setTimeout(tryInit, RETRY_DELAY_MS);
      } else {
        console.warn(`${LOG} Gave up after ${MAX_RETRIES} retries.`);
        debugDump();
        buildUI(); rebuildOutline(); startMsgObserver();
      }
      return;
    }

    console.log(`${LOG} Initialised with selector: "${activeSelector}"`);
    buildUI();
    rebuildOutline();
    startMsgObserver();
  }

  let appObserver = new MutationObserver(() => {
    for (const sel of USER_MSG_SELECTORS) {
      try {
        if (document.querySelectorAll(sel).length > 0) {
          appObserver.disconnect(); appObserver = null;
          tryInit(); return;
        }
      } catch (e) { /* skip */ }
    }
  });

  // ─── SPA Navigation ───────────────────────────────────────────────────────

  let lastUrl = location.href;

  function onNavigate() {
    const newUrl = location.href;
    if (newUrl === lastUrl) return;   // deduplicate (replaceState fires on every keystroke in some SPAs)
    lastUrl = newUrl;

    console.log(`${LOG} Navigation detected → ${newUrl}`);

    activeSelector = null;
    retryCount = 0;
    messageStore = [];
    lastRenderedTexts = [];
    cachedScrollContainer = null;
    activeIdx = -1;
    clearTimeout(highlightTimer);
    if (intersectionObserver) { intersectionObserver.disconnect(); intersectionObserver = null; }

    // Clear outline DOM immediately so stale items don't linger
    if (listEl) {
      listEl.innerHTML = '';
      const placeholder = document.createElement('div');
      placeholder.className = 'kimi-outline-empty';
      placeholder.textContent = '加载中…';
      listEl.appendChild(placeholder);
    }
    if (countEl) countEl.textContent = '';

    setTimeout(tryInit, 500);
  }

  // Patch pushState AND replaceState — Kimi uses replaceState when switching conversations
  const origPushState = history.pushState.bind(history);
  history.pushState = function (...args) { origPushState(...args); onNavigate(); };

  const origReplaceState = history.replaceState.bind(history);
  history.replaceState = function (...args) { origReplaceState(...args); onNavigate(); };

  window.addEventListener('popstate', onNavigate);

  // Fallback polling: catch any navigation that bypasses the history API patches
  setInterval(() => { if (location.href !== lastUrl) onNavigate(); }, 800);

  // ─── Entry Point ──────────────────────────────────────────────────────────

  function init() {
    console.log(`${LOG} Starting…`);
    if (appObserver) appObserver.observe(document.body, { childList: true, subtree: true });
    tryInit();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
